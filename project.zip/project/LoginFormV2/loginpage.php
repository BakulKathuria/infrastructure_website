<?php include("function.php");?>
<script type="text/javascript">
$(function() {
  $('form').submit(function(){
    $.post('http://example.com/upload', function() {
      window.location = 'http://google.com';
    });
    return false;
  });
});
</script>
<!DOCTYPE html>
    <html>
        <head>
            <title>Login Form with PHP</title>
        <link rel="stylesheet" type="text/css" href="css/login.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
        </head>
<body>
    
    <div class="container">
        <img src="C:\xampp\htdocs\LoginFormV2\images\login.jpg" />
        
        <div style = "font-size:20px; color:#7de750; margin-top:1px">
		<b><?php if(isset($send)){echo $send;} ?></b>
		<?php if(isset($new)){echo "<script type='text/javascript'> alert('$new');</script>";} ?>
		</div>
		<div style = "font-size:20px; color:#d02513; margin-top:1px">
		<b><?php if(isset($sen)){echo "<script type='text/javascript'>alert('$sen');</script>";}?></b>

		<b><?php if(isset($send)){echo "<script type='text/javascript'>alert('$send');</script>";}?></b>		
		
		</div>
		
        <form action="loginpage.php" method="post">
            <div class="form-input">
                <input type="text" name="email" placeholder="E-mail" required />
            </div>
            <div class="form-input">
                <input type="password" name="pwd" placeholder="Enter password"  required />
            </div>
			
			<input type="checkbox" name="cselect" value="yes" autofocus>
			Rember me
			
			
            <button name="login" class="btn-login">Submit<button/>
            <p><a href="http://localhost/project/forgetpassword/forget_password.php">Forget password?</a></p>
        </form>
    </div>
    
</body>
</html>