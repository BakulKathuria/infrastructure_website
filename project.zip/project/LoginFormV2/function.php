<?php
	if(isset($_POST['login'])){
		$ok="";
		$hname="localhost";
		$uname="root";
		$password="";
		$databasename="registerdb";
		$connect=mysqli_connect($hname,$uname,$password,$databasename);
		$email=$_POST['email'];
		$pwd=$_POST['pwd'];
		$check=$_POST['yes'];
		
		$query="select * from form_of_register where email='$email' and password='$pwd'";
		$res=mysqli_query($connect,$query);
		$new=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if($count!=0){
			if(!empty(_POST['cselect'])){
			header('location: https://www.facebook.com/');
			}
			else{
				header('location: https://www.google.co.in/');
			}
		}
		else{
			$sen="login Unsuccessfull";
		}
	}
	?>