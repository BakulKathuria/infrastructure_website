<?php include("functionf.php");?>
<!DOCTYPE html>
    <html>
        <head>
            <title>Forget Form</title>
        <link rel="stylesheet" type="text/css" href="css/login.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
        </head>
<body>
    
    <div class="container">
        <img src="C:\xampp\htdocs\project\forgetpassword\images\log4.jpg" />
        
        <div style = "font-size:20px; color:#7de750; margin-top:1px">
		<?php if(isset($sendto)){echo "<script type='text/javascript'>alert('$sendto')";} ?>
		</div>
		<img src="C:\xampp\htdocs\project\forgetpassword\images\log4.jpg"/>
        <form action="forget_password.php" method="post">
            <div class="form-input">
                <input type="text" name="user" placeholder="User Name(First name)" required autofocus />
            </div>
           
			<div class="form-input">
                <input type="text" name="email" placeholder="Email"  required autofocus />
            </div>
			<div class="form-input">
                <input type="number" name="mobile" placeholder="Mobile no"  required autofocus />
            </div>
			<div class="form-input">
                <input type="password" name="npwd" placeholder="New password"  required autofocus />
            </div>
			<div class="form-input">
                <input type="password" name="confpwd" placeholder="Confirm password"  required autofocus />
            </div>
			<div style = "font-size:20px; color:#d02513; margin-top:1px">
		<?php if(isset($error)){echo "<script type='text/javascript'>alert('$error')";} ?>
		</div>
			
            <button name="login" class="btn-login" type="submit" formtarget="localhost\LoginFormV2\loginpage.php">Continue<button/>
            
        </form>
    </div>
    
</body>
</html>