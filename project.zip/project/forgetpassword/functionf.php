<?php
	if(isset($_POST['login'])){
		
		$ok="";
		$hname="localhost";
		$uname="root";
		$password="";
		$databasename="registerdb";
		$connect=mysqli_connect($hname,$uname,$password,$databasename);
		$user=$_POST['user'];
		$email=$_POST['email'];
		$mobile=$_POST['mobile'];
		$npwd=$_POST['npwd'];
		$confpwd=$_POST['confpwd'];
		
		if($confpwd==$npwd){
			$pok=$confpwd;
			$query="UPDATE form_of_register set password='$pok' where first_name='$user' and email='$email' and phone='$mobile'";
			$res=mysqli_query($connect,$query);
			$count=mysqli_num_rows($res);
			if($count!=0){
				$sendto="You have succesfully changed password<br> click below link to ReLogin";
			}
			else{
				$sendto="Session expired try again <br> Referesh the page";
			}
		}
		else{
			$error="You have enter wrong #INFO*";
		}
		
	}
	
	?>