<?php 
session_destroy();
echo "<script type="text/javascript">alert("Sessio expired")</script>";

?>