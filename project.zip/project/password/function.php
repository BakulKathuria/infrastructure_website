<?php include("functionf.php ");?>
<?php
	if(isset($_POST['login'])){
		//session_start();
		$ok="";
		$hname="localhost";
		$uname="root";
		$password="";
		$databasename="registerdb";
		$connect=mysqli_connect($hname,$uname,$password,$databasename);
		
		$newpwd=$_POST['newpwd'];
		$confpwd=$_POST['confpwd'];
		if($newpwd==$confpwd){
			$p=$confpwd;
			$query="update form_of_register set password='$p' where first_name='$user' and email='$email' and  mobile='$mobile'";
			$res=mysqli_query($connect,$query);
			$count=mysqli_affected_rows($res);
			if($count==1){
			$success="Successfully change";
			header("location: 'http://localhost/project/LoginFormV2/loginpage.php'");
		}
		else{
			$error="Nothing can be done now";
			}
	}
		else{
			$error="Unsuccessfully try again";
			//header("location: 'http://localhost/project/forgetpassword/destroy.php'");
		}
		
		
	}
	?>