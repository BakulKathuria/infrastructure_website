<?php include("function.php");?>
<!DOCTYPE html>
    <html>
        <head>
            <title>Forget Form</title>
        <link rel="stylesheet" type="text/css" href="css/login.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
        </head>
<body>
    
    <div class="container">
        <img src="C:\xampp\htdocs\LoginFormV2\images\login.jpg" />
        
        <div style = "font-size:20px; color:#7de750; margin-top:1px">
		<?php if(isset($success)){echo "<script type='text/javascript'>alert('$success')</script>";} ?>
		</div>
		
        <form action="forgetpage2.php" method="post">
            <div class="form-input">
                <input type="password" name="newpwd" placeholder="New password" required autofocus />
            </div>
            <div class="form-input">
                <input type="password" name="confpwd" placeholder="Confirm password" autofocus required />
            </div>
			
			<div style = "font-size:20px; color:#d02513; margin-top:1px">
		<?php if(isset($sen)){echo "<script type='text/javascript'>alert('$error')</script>";} ?>
		</div>
			
            <button name="login" class="btn-login">Continue<button/>
            
        </form>
    </div>
    
</body>
</html>