<?php include("function.php");?>
<!DOCTYPE html>
    <html>
        <head>
            <title>Registration Form with PHP</title>
        <link rel="stylesheet" type="text/css" href="css/login.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
        </head>
<body>
    
    <div class="container">
        <img src="C:\xampp\htdocs\register\images\logo.jpg" />
        
        <div class="user-text">
		
		</div>
		<div style = "font-size:20px; color:#7de750; margin-top:1px">
		<?php if(isset($success)){echo "<script type='text/javascript'> alert('$success');</script>";} ?>
		
		</div>
		
        <form action="register.php" method="post">
            <div class="form-input">
                <input type="text" name="fname" placeholder="First Name" required autofocus />
            </div>
			<div class="form-input">
                <input type="text" name="lname" placeholder="Last Name"required autofocus />
            </div>
           <div class="form-input">
                <input type="text" name="l" placeholder="Email Address"required autofocus />
            </div>
			<div class="form-input">
                <input type="number" name="m" placeholder="Mobile_No"required autofocus />
            </div>
			<textarea name="address" cols="10" rows="5" placeholder="Address" maxlength="200"required autofocus>
			</textarea>
			<div class="form-input">
                <input type="number" name="zip" placeholder="Zip code"required autofocus />
            </div>
			<div class="form-input">
                <input type="password" name="orignalpassword" placeholder="Password"required autofocus max="16"min="4" />
            </div>
			<div class="form-input">
                <input type="password" name="confirmpassword" placeholder="Confirm password"required autofocus min="4" max="16"/>
            </div>
			<div style = "font-size:20px; color:#cc0000; margin-top:1px">
		<?php if(isset($ok)){echo $ok;} ?>
		</div>
			<div style="color: white; margin-right: 100px">
			<b><i>Already have an account?</i></b></div>
			<div style="margin-bottom: 2px"><a href="http://localhost/project/LoginFormV2/loginpage.php">Login</a></div>
            <br>
			<a href="http://localhost/project/LoginFormV2/loginpage.php"><button name="register" class="btn-login">Register<button/></a>
		</form>
    </div>
    
</body>
</html>