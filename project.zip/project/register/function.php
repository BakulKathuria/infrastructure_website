<?php
	if(isset($_POST['register'])){
		
	    $ok="";
		$hname="localhost";
		$uname="root";
		$password="";
		$databasename="registerdb";
		$connect=mysqli_connect($hname,$uname,$password,$databasename);
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['l'];//ye nhi chal rha
		$mobile=$_POST['m'];//ye nhi chal rha
		$address=$_POST['address'];
		$zip=$_POST['zip'];
		$opwd=$_POST['orignalpassword'];
		$cpwd=$_POST['confirmpassword'];
		
		if($opwd!=$cpwd){
			$ok="Password doesn't Match";
			
		}
		else{
			
			
		
		$query="insert into form_of_register values('$fname','$lname','$email','$mobile','$address','$zip','$opwd')";
		$res=mysqli_query($connect,$query);
		if($res){
			
			$success="Register succesfully";
		}
		else{
			$s="Register Unsuccessfully";
			exit();
		}
	}
	}
	?>